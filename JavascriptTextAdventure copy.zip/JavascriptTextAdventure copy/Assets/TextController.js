﻿#pragma strict
import UnityEngine.UI;  //We can use these special lines at the top to import more code from pre-built libraries giving us more functionality.

public var textObject : UI.Text;  //By default every variable is set to private.  In this case we want this variable publicly visible so we can easily use it within Unity.
public var textTitle: UI.Text;
public var backgroundImage: UI.Image;
public var images: Sprite[]; 
public var thelock = 1;
public var pin = 1;
public var cargo = 1;
public enum States {intro, cott, window, myLock, hall, cell, leftHall, rightHall, guard, deck, death, lifeBoat, cargo};  //An enum is a special type of variable that allows us to name each number with a name. (instead of it just being a number).
public var myState : States;  //Think of this as the parent variable that we use, with the enum value held inside.  (myState.intro)

function Start () {  //The start function runs once, the first time this object loads.
    myState = States.intro;  //We want to make sure the myState gets assigned to .intro
}

function Update () {
    print (myState);  //This will display the myState value within the console.  This might be helpful if there is a problem and the text doesn't get properly updated on the normal screen.
    if (myState == States.intro) 					{state_intro ();}
    else if (myState == States.cott) 				{state_cott ();}
    else if (myState == States.window)				{state_window ();}
    else if (myState == States.myLock)				{state_myLock ();}
    else if (myState == States.hall)                {state_hall ();}
    else if (myState == States.cell)                {state_cell ();}
    else if (myState == States.leftHall)            {state_leftHall();}
    else if (myState == States.rightHall)           {state_rightHall();}
    else if (myState == States.guard)               {state_guard();}
    else if (myState == States.deck)                {state_deck();}
    else if (myState == States.death)           	{state_death();}
    else if (myState == States.lifeBoat)            {state_lifeBoat();}
    else if (myState == States.cargo)               {state_cargo();}
}

function state_intro(){
    pin = 1;
    thelock = 1;
    cargo = 1;
    backgroundImage.sprite = images[1];
    textTitle.text = "Health: Weak";
    textObject.text = "You awake in a prison cell. \n" +
        "There is an uncomfortable cott with ominous stains. \n" +
        "There is a window with a view outside. \n" +
        "There is a door with a lock. \n" +
        "\n\n" +
        "Press C to look at the Cott, W to look out the Window, L to look at the Lock.";
    if (Input.GetKeyDown (KeyCode.C)) 					{myState = States.cott;}
    if (Input.GetKeyDown (KeyCode.W)) 					{myState = States.window;}
    if (Input.GetKeyDown (KeyCode.L)) 					{myState = States.myLock;}
}

function state_cell(){
    backgroundImage.sprite = images[1];
    textObject.text = "There is an uncomfortable cott with ominous stains. \n" +
        "There is a window with a view outside. \n" +
        "There is a door with a lock. \n" +
        "\n\n" +
        "Press C to look at the Cott, W to look out the Window, L to look at the Lock.";
    
    if (Input.GetKeyDown (KeyCode.C))                   {myState = States.cott;}
    if (Input.GetKeyDown (KeyCode.W))                   {myState = States.window;}
    if (Input.GetKeyDown (KeyCode.L))                   {myState = States.myLock;}
}

function state_cott(){
    backgroundImage.sprite = images[1];
    if (thelock < 2) {textObject.text = "The cott looks uncomfortable to sleep on, \n" +
        "with slim blankets that would hardly keep you warm. \n" +
        "Upon closer inspection, the stains look even more ominous. \n" +
        "There is a window with a view outside. \n" +
        "There is a door with a lock. \n" +
        "\n\n" +
        "Press C to look at the Cell, W to look out the Window, L to look at the Lock.";
    }else{ textObject.text = "You now notice just underneath the cott there is a bobby pin. \n" +
        "Perhaps you can use this bobby pin to pick the lock! \n" +
        "\n\n" +
        "\n\n"+
        "\n\n"+
        "Press L to look at the lock.";
    pin = 2;
}
    if (Input.GetKeyDown (KeyCode.C)) 					{myState = States.cell;}
    if (Input.GetKeyDown (KeyCode.W)) 					{myState = States.window;}
    if (Input.GetKeyDown (KeyCode.L)) 					{myState = States.myLock;}
}

function state_window(){
    backgroundImage.sprite = images[1];
    textObject.text = "You look out the window to see only ocean. \n" +
        "In fact the whole horizon looks like it's tilting. \n" +
        "Maybe you are on a ship? \n" +
        "There is a door with a lock. \n" +
        "\n\n" +
        "Press C to look at the Cell, L to look at the Lock.";
    if (Input.GetKeyDown (KeyCode.C)) 					{myState = States.cell;}
    if (Input.GetKeyDown (KeyCode.L)) 					{myState = States.myLock;}
}

function state_myLock(){
    backgroundImage.sprite = images[1];
    if (pin < 2) {textObject.text = "You examine the lock. \n" +
        "The lock is very sturdy. \n" +
        "You cannot get out of the cell. Maybe you should look around some more...\n" +
        "\n\n" +
        "Press C to look at the Cell.";
    thelock = 2;
    }else{
        textObject.text = "You examine the lock. \n" +
            "The bobby pin looks to be the right size for the keyhole. \n" +
            "\n\n" + 
            "\n\n" +
            "Press L to pick the lock, C to look at the cell.";
    }
    if (Input.GetKeyDown (KeyCode.C))                   {myState = States.cell;}
    if (Input.GetKeyDown (KeyCode.L))                   {myState = States.hall;}

}

function state_hall(){
    textTitle.text = "Health: Strong";
    backgroundImage.sprite = images[2];
    textObject.text = "You find yourself in a long hallway. \n" +
        "The floor is covered in grime. \n" +
        "There is a light coming from the left but the hallway to the right is dark.\n" +
        "\n\n"+
        "\n\n" +
        "Press L to go left, R to go right.";
    if (Input.GetKeyDown (KeyCode.L))                   {myState = States.leftHall;}
    if (Input.GetKeyDown (KeyCode.R))                   {myState = States.rightHall;}

}

function state_leftHall(){
    backgroundImage.sprite = images[2];
    textObject.text = "As you walk down the hallway you begin to hear a deep gutteral laugh. \n" +
        "\n \n" +
        "\n\n" +
        "\n\n" +
        "Press C to continue, B to go back.";
    if (Input.GetKeyDown (KeyCode.C))                   {myState = States.guard;}
    if (Input.GetKeyDown (KeyCode.B))                   {myState = States.hall;}

}

function state_guard(){
    backgroundImage.sprite = images [3];
    textTitle.text = "Health: Dead";
    textObject.text = "A large burly man spots you and shouts. \n" +
        "He picks up a gun and points it at you.\n" +
        "He fires one loud shot into your body. \n"+
        "You are now <color=red>dead</color>. \n" +
        "\n\n" +
        "Press C to continue.";
    if (Input.GetKeyDown (KeyCode.C))                   {myState = States.intro;}
}

function state_rightHall(){
    backgroundImage.sprite = images [4];
    textObject.text = "You go down the dark hallway. \n" +
        "You hear flowing water and begin to see light. \n" +
        "As you progress you see stairs leading up toward the light. \n" +
        "\n\n" +
        "Press C to go up the stairs, B to go back.";
    if (Input.GetKeyDown (KeyCode.C))                   {myState = States.deck;}
    if (Input.GetKeyDown (KeyCode.B))                   {myState = States.hall;}
}

function state_deck(){
    backgroundImage.sprite = images [5];
    textObject.text = "You find yourself on the deck of a large ship. \n" +
        "You don't see anyone on the deck.\n" +
        "You notice lifeboats to your right and cargo containers to your left.\n"+
        "Straight ahead is simply the open deck. \n" +
        "\n\n"+
        "Press R to go to the lifeboats, L to go to the cargo containers, and C to the open deck.";
    if (Input.GetKeyDown (KeyCode.C))                   {myState = States.death;}
    if (Input.GetKeyDown (KeyCode.R))                   {myState = States.lifeBoat;}
    if (Input.GetKeyDown (KeyCode.L))                   {myState = States.cargo;}

}

function state_death(){
    
    if(cargo >= 2){
        textTitle.text = "Health: Dead";
        textObject.text = "You hear a shout behind you.\n"+
        "You don't have a chance to turn around before you hear the gunfire. \n"+
        "\n\n"+
        "\n\n"+
        "You are <color=red>dead</color>.\n"+
        "Press C to continue.";
}else{

  backgroundImage.sprite = images [7];
        textObject.text = "As you make your way out onto the deck, you look around suspiciously. \n"+
        "You don't see anyone around. \n"+
        "As you look around you notice the lifeboats again to your right. \n"+
        "\n\n"+
        "Press R to go to the lifeboats.";
}      
    if (Input.GetKeyDown (KeyCode.C))                   {myState = States.intro;}
    if (Input.GetKeyDown (KeyCode.R))                   {myState = States.lifeBoat;}
}


function state_cargo(){
    backgroundImage.sprite = images [6];
    textObject.text = "You find a stack of cargo containers of varying colors. \n" +
        "\n\n"+
        "\n\n"+
        "\n\n"+
        "Press D to open a container, C to go back.";
    if(Input.GetKeyDown(KeyCode.D)) {textObject.text = "The container booms loudly as you try to open the door. \n"+
        "You glance around nervously. \n"+
        "The doors all appear to be locked.\n"+
        "\n\n"+
        "Press C to go back, D to go out onto the deck.";
        cargo = 2;
        if(Input.GetKeyDown(KeyCode.D))                 {myState = States.death;}
        if(Input.GetKeyDown(KeyCode.C))                 {myState = States.deck;}
}
    if(Input.GetKeyDown(KeyCode.C))                     {myState = States.deck;}

}

function state_lifeBoat(){
    backgroundImage.sprite = images [8];
    textObject.text = "You climb into the lifeboat and start the engine. \n"+
        "The lifeboat speeds away from the ship. \n"+
        "You have escaped! \n"+
        "\n\n"+
        "Press C to restart.";
    if(Input.GetKeyDown(KeyCode.C))                     {myState = States.intro;}
}

